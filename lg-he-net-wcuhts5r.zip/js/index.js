var _gaq = _gaq || [];
_gaq.push (['_setAccount', 'UA-26518558-1']);
_gaq.push (['_trackPageview']);
			
(function() {
	var ga = document.createElement ('script');
	ga.type = 'text/javascript';
	ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	var s = document.getElementsByTagName ('script') [0];
	s.parentNode.insertBefore (ga, s);
}) ();

function checkIP () {
	var ip4Test = /^[0-9\.\/]+$/i;
	var ip6Test = /^[:0-9a-f\/]+$/i;
	if(!$('#ip').val().trim() || ip4Test.test($('#ip').val().trim()) || ip6Test.test($('#ip').val().trim())) {
		$('.hostnameOnly').hide();
	} else {
		$('.hostnameOnly').show();
	}
}

function checkRemotes () {
	var numTservs = $('#lg_routers * input[type="checkbox"][traceroute="y"]:checked').length;
	if(numTservs) {
		$('#command_traceroute').removeAttr('disabled');
	} else {
		$('#command_traceroute').attr('disabled', 'disabled');
	}
}

function setdisplay (id, value) {
	if (document.getElementById) {
		document.getElementById (id).style.display = value;
	}
}

$.tablesorter.addParser ({
	id: 'ip',
	is: function (s) {
		return (false);
	},
	format: function (s) {
		var i, quads, parts, mask;
		mask = '';
					
		if (s.indexOf ('/') != -1) {
			parts = s.split ('/');
			s = parts [0];
			mask = String.fromCharCode (parts [1]);
		}
					
		if (s.indexOf (':') != -1) {
			// IPv6
			var parts, quads, i;
						
			if (s.indexOf ('::') != -1) {
				parts = s.split ('::');
				s = '';
				quads = 0;
				for (i = 0; i < parts.length; i++) {
					quads += parts [i].split (':').length;
				}
				s += parts [0] + ':';
				for (var i = 0; i < 8 - quads; i++) {
					s += '0000:';
				}
				s += parts [1];
			}
			parts = s.split (':');
			s = '';
			for (i = 0; i < 4; i++) {
				while (parts [i].length < 4) {
					parts [i] = '0' + parts [i];
				}
				s += ((i != 4 - 1) ? ':' : '') + parts [i];
			}
			return ('v6_' + s + mask);
		} else {
			// IPv4
			parts = s.split ('.');
			return ('v4_' + String.fromCharCode (parts [0]) + String.fromCharCode (parts [1]) + String.fromCharCode (parts [2]) + String.fromCharCode (parts [3]) + mask);
		}
	},
	type: 'text'
});

$.tablesorter.addParser ({
	id: 'duration',
	is: function (s) {
		return (false);
	},
	format: function (s) {
		var ret = 0;
		s = s.replace (/ /, '');
					
		while (value = s.match (/^\d+/)) {
			value = value [0];
			s = s.replace (/^\d+/, '');
			unit = s.match (/^[a-z]/);
			unit = unit [0];
			s = s.replace (/^[a-z]/, '');
						
			switch (unit) {
				case 'y':
					unit = 365.25 * 24 * 60 * 60;
					break;
				case 'd':
					unit = 24 * 60 * 60;
					break;
				case 'h':
					unit = 60 * 60;
					break;
				case 'm':
					unit = 60;
					break;
				case 's':
					unit = 1;
					break;
				default:
					return (0);
			}
			ret += value * unit;
		}
		return (ret);
	},
	type: 'numeric'
});

checkRemotes();
$(function () {
	$("table").tablesorter ({});
	$('#ip').on('blur keyup', function() {
		checkIP();
	});
	$('#lg_routers * input[type="checkbox"]').on('change', function() {
		var numChecked = $('#lg_routers * input[type="checkbox"]:checked').length;
		if(numChecked > 3) {
			alert('Please select no more than 3 routers at one time.');
			$(this).removeAttr('checked');
		}
		checkRemotes();
	});
	$('input[name=command]').on('change', function() {
		if($(this).data('placeholder')) {
			$('#ip').attr('placeholder', $(this).data('placeholder'));
		} else {
			$('#ip').attr('placeholder', '');
		}		
	});
	$('#showOptions').on('click', function() {
		$('#options').toggle();
	});
	$('#clear').on('click', function() {
		$('input[type=checkbox]').prop('checked', false);
		$('#ip').val('');
		$('input[name=command]').prop('checked', false);
		$('input[name=command][value=traceroute]').trigger('click');
	});
	checkIP();
});
