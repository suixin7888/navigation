(function (d) {
  var c = d.createElement('link')
  c.rel = 'stylesheet'
  c.href = 'css/he-simple.css'
  var s = d.createElement('script')
  s.src = 'js/he-simple.js'
  var sn = d.getElementsByTagName('script')[0]
  sn.parentNode.insertBefore(c, sn)
  sn.parentNode.insertBefore(s, sn)
})(document)
